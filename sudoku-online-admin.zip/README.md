# Sudoku Online + Admin
1. ثبت Node.js.
2. افتح Terminal داخل المجلد وشغل: `npm install`
3. غيّر كلمة مرور الأدمن عبر متغير البيئة `ADMIN_PASSWORD`، ولا تضع كلمة حقيقية داخل Git.
4. شغل: `npm start`
5. اللعبة: `/`
6. لوحة الأدمن: `/admin`
7. هذه النسخة لا تحتاج OpenAI API key.
