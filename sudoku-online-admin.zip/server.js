const express=require("express");
const http=require("http");
const {Server}=require("socket.io");
const path=require("path");
const app=express();
const server=http.createServer(app);
const io=new Server(server);
const PORT=process.env.PORT||3000;
const ADMIN_PASSWORD=process.env.ADMIN_PASSWORD||"change-me-1234";
let theme={background:"#101827",card:"#172235",accent:"#4ade80",text:"#ffffff"};

app.use(express.static(path.join(__dirname,"public")));
app.get("/admin",(req,res)=>res.sendFile(path.join(__dirname,"public","admin.html")));

io.on("connection",socket=>{
  socket.emit("theme",theme);
  socket.on("admin-login",password=>{
    if(password===ADMIN_PASSWORD){
      socket.data.admin=true;
      socket.emit("admin-auth",true);
    }else socket.emit("admin-auth",false);
  });
  socket.on("set-theme",next=>{
    if(!socket.data.admin) return;
    const clean={
      background:String(next.background||theme.background),
      card:String(next.card||theme.card),
      accent:String(next.accent||theme.accent),
      text:String(next.text||theme.text)
    };
    theme=clean;
    io.emit("theme",theme);
  });
});
server.listen(PORT,()=>console.log(`Sudoku running on http://localhost:${PORT}`));